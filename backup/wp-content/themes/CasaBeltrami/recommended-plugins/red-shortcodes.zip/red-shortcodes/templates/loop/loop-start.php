<?php
/**
 * Posts Loop Start
 *
 */

global $view_type;
?>
<div class=" red-list-posts <?php echo $view_type?>">